/* quoted literals get preserved, in several forms */
var double_quoted=" double quoted strings /* with block comments */ ";
