/* use of "/" for division should get compacted */
var foo = 10 / 2;
