/* quoted literals get preserved, in several forms */
var regexes=/ regexes stay /;
